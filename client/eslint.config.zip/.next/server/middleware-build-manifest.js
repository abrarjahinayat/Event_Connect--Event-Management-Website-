globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/033ee3d87a520783.js",
    "static/chunks/06a35815abfedae3.js",
    "static/chunks/57e3f3b2bb3bd78c.js",
    "static/chunks/58d86e5693a0dbc6.js",
    "static/chunks/turbopack-96d9d2d4f1621ccd.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];