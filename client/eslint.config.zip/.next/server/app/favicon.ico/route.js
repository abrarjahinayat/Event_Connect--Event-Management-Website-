var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__cd861506._.js")
R.c("server/chunks/client__next-internal_server_app_favicon_ico_route_actions_dfa06a2e.js")
R.m(90076)
module.exports=R.m(90076).exports
