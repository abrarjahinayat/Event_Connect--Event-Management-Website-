module.exports=[37061,(e,o,d)=>{}];

//# sourceMappingURL=client__next-internal_server_app_favicon_ico_route_actions_dfa06a2e.js.map