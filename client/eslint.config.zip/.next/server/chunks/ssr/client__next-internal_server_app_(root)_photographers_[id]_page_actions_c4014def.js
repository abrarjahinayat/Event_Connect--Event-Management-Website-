module.exports=[23281,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_%28root%29_photographers_%5Bid%5D_page_actions_c4014def.js.map