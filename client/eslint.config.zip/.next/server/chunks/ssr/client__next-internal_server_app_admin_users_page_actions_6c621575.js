module.exports=[7075,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_admin_users_page_actions_6c621575.js.map