module.exports=[87917,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_vendor_add-service_page_actions_58630327.js.map