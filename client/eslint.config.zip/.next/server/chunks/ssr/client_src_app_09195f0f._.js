module.exports=[35631,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},19363,a=>{"use strict";let b={src:a.i(35631).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=client_src_app_09195f0f._.js.map