module.exports=[86712,(a,b,c)=>{}];

//# sourceMappingURL=5cf68__next-internal_server_app_%28root%29_cooks-caterers_%5Bid%5D_page_actions_3bb43433.js.map