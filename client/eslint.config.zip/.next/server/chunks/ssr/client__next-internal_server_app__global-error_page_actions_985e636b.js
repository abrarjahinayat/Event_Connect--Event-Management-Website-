module.exports=[53261,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app__global-error_page_actions_985e636b.js.map