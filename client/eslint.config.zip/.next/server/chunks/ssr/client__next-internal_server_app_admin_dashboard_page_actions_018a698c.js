module.exports=[76049,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_admin_dashboard_page_actions_018a698c.js.map