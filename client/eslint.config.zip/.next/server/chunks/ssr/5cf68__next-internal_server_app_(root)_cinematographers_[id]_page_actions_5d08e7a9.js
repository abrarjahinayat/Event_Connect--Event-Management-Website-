module.exports=[96539,(a,b,c)=>{}];

//# sourceMappingURL=5cf68__next-internal_server_app_%28root%29_cinematographers_%5Bid%5D_page_actions_5d08e7a9.js.map