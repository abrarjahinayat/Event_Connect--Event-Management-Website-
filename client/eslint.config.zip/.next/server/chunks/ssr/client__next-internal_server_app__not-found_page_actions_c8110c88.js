module.exports=[484,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app__not-found_page_actions_c8110c88.js.map