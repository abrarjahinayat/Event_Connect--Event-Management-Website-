module.exports=[37170,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_user_login_page_actions_2b15e694.js.map