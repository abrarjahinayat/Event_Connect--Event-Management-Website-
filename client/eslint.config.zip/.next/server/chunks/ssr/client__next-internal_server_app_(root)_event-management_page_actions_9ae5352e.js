module.exports=[20290,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_%28root%29_event-management_page_actions_9ae5352e.js.map