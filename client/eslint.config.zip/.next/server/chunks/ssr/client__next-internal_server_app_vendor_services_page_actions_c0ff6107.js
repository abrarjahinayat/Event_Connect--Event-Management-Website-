module.exports=[63304,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_vendor_services_page_actions_c0ff6107.js.map