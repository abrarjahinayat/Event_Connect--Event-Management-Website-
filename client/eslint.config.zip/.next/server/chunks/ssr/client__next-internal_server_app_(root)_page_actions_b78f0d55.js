module.exports=[19430,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_%28root%29_page_actions_b78f0d55.js.map