module.exports=[27362,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_vendor_edit-service_%5Bid%5D_page_actions_3c16730d.js.map