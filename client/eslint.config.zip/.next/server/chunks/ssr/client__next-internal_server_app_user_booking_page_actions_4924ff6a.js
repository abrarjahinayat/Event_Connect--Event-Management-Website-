module.exports=[22643,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_user_booking_page_actions_4924ff6a.js.map