module.exports=[98506,(a,b,c)=>{}];

//# sourceMappingURL=5cf68__next-internal_server_app_%28root%29_event-management_%5Bid%5D_page_actions_875ba9b1.js.map