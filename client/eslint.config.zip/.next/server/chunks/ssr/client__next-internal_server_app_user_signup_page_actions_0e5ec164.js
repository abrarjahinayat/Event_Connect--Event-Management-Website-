module.exports=[20631,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_user_signup_page_actions_0e5ec164.js.map