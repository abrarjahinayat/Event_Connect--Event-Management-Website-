module.exports=[82915,(a,b,c)=>{}];

//# sourceMappingURL=5cf68__next-internal_server_app_%28root%29_production-houses_%5Bid%5D_page_actions_497c031b.js.map