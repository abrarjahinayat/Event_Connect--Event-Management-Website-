module.exports=[41350,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_vendor_settings_page_actions_9c0a0161.js.map