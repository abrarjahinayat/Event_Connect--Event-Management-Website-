module.exports=[70842,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_%28root%29_booking_page_actions_82b72ff3.js.map