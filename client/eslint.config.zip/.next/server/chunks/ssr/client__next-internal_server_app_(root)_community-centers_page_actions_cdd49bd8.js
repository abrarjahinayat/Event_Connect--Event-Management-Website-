module.exports=[50822,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_%28root%29_community-centers_page_actions_cdd49bd8.js.map