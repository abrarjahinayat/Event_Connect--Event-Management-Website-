module.exports=[22188,(a,b,c)=>{}];

//# sourceMappingURL=5cf68__next-internal_server_app_%28root%29_booking_payment-failed_page_actions_78d76887.js.map