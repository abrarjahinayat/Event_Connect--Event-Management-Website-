module.exports=[61815,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_admin-login_page_actions_5fdd03e6.js.map