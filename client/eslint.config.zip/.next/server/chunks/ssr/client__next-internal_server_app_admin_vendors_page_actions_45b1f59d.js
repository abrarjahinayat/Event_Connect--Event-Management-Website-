module.exports=[13512,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_admin_vendors_page_actions_45b1f59d.js.map