module.exports=[8005,(a,b,c)=>{}];

//# sourceMappingURL=5cf68__next-internal_server_app_vendor_update-availability_%5Bid%5D_page_actions_d7f7b733.js.map