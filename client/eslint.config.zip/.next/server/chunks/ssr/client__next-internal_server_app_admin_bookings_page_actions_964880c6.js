module.exports=[70741,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_admin_bookings_page_actions_964880c6.js.map