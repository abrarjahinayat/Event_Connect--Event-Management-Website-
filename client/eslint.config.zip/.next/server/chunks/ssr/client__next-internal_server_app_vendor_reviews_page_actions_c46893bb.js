module.exports=[32728,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_vendor_reviews_page_actions_c46893bb.js.map