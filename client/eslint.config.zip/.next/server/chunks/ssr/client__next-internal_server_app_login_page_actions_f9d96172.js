module.exports=[24146,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_login_page_actions_f9d96172.js.map