module.exports=[84822,(a,b,c)=>{}];

//# sourceMappingURL=client__next-internal_server_app_%28root%29_cinematographers_page_actions_10784f96.js.map