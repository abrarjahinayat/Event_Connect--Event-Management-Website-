module.exports=[93327,(a,b,c)=>{}];

//# sourceMappingURL=5cf68__next-internal_server_app_%28root%29_booking_payment-success_page_actions_f6b4eca7.js.map